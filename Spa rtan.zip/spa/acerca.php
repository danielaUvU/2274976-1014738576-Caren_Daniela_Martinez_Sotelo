<body> 
<img src="imagenes/SPA3.jpg "width="120" height="60" align="left">
    <ul class="menu">
        <li> <a href="km.php"> Inicio </a></li>
        <li> <a href="servicio.php"> Atencion al cliente </a></li>
        <li> <a href="acerca.php"> Acerca de  </a></li>
        <li> <a href="contac.php"> Contactos </a></li>
        <link rel="stylesheet" href="css/estilo.css">
<p> <br>
        <body>
          
      <center>   <h1 class="title"> <font= face="Algerian">- SPA RTAN -<h1> </center> 
<p> <center>
Somos una empresa de relajamiento <br>
Esta conformada por Caren, Danna y Johana <br>
Vas a encontrar todas las maquinas que tiene Spa rtan <br>
El horario es 24/7 <br>
Es muy cómodo, tendrás un instructor personal, te podrá ayudar con lo necesario que necesitas <br>
Hay clases de baile días jueves y viernes de 6 a 10 de la mañana o de 5 a 8 de la noche <br>
Hay una tienda deportiva <br>
Hay agua envasada para su digestión <br>
</center> <p><br>
<marquee> <img src="imagenes/12.jpg "width="200" height="100"> <img src="imagenes/MA.jpg "width="200" height="100"></marquee>
