<body> 
<img src="imagenes/SPA3.jpg "width="120" height="60" align="left">
    <ul class="menu">
        <li> <a href="km.php"> Inicio </a></li>
        <li> <a href="servicio.php"> Atencion al cliente </a></li>
        <li> <a href="acerca.php"> Acerca de  </a></li>
        <li> <a href="contac.php"> Contactos </a></li>
        <link rel="stylesheet" href="css/estilo.css">
<p> <br>
        <body>
      <center>   <h1 class="title"> <font= face="Algerian">- SPA RTAN -<h1> </center> 
      <p> <center>
      
Si tienes alguna queja, reclamo, o necesitas información 
Comunícate con nosotros. <br><p>
Gmail: <br>
spartam@gmail.com <br>
spartam@hotmail.com <br>
teléfonos: <br> Caren – 3164782658 <br>
                   Danna – 3214587596 <br>
                   Johana – 3204873648 <br>
Teléfono fijo: <br> 745869 – Empresa<br>
                        754826 -- Empresa <br>
                        <p><br>
                        <marquee> <img src="imagenes/14.jpg"> </marquee>
