<DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title> Menu de navegacion con listas  </title>
<link rel="stylesheet" href="css/estilo.css">
</head>
<body> 
<img src="imagenes/SPA3.jpg "width="120" height="60" align="left">
<body background="logi.jpg">
    <ul class="menu">
        <li> <a href="km.php"> Inicio </a></li>
        <li> <a href="servicio.php"> Atencion al cliente </a></li>
        <li> <a href="acerca.php"> Acerca de  </a></li>
        <li> <a href="contac.php"> Contactos </a></li>
        <p>
        <table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Exfoliación corporal</center>
    <br><img src="imagenes/exso.jpg "width="200" height="100" align="left"></td>
    <td>sirve para eliminar las células muertas que se acumulan en la superficie de la piel,<br>
    favorecer el proceso de renovación celular, activar la microcirculación y el drenaje y, en <br>
     definitiva, conseguir que nuestra piel esté más bonita, más luminosa, más homogénea y más<br>
    suave</td>
    </tr>
</table>
<table border=10 align="right">
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Limpieza facial </center>
    <br><img src="imagenes/hom.jpg "width="200" height="100" align="left"></td>
    <td> es más que solo echarte agua al rostro y secártelo con una toalla. Una limpieza <br>
    consiste en limpiar la piel a fondo, hidratarla y fotoprotegerla. Ayuda a eliminar <br>
    los rastros de suciedad, maquillaje, sebo, contaminación y células muertas de la piel</td>
    </tr>
</table>
<table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Cuidado especial de<br> pies y manos.</center>
    <br><img src="imagenes/feo.jpg "width="200" height="100" align="left"></td>
    <td>La manicura y la pedicura son los tratamientos responsables del cuidado y <br>
    embellecimiento de las manos, pies y uñas. La preocupación de estas “artes” va más<br>
     allá de la forma y color de las uñas o del simple aspecto físico de nuestras extremidades;<br>
      el cuidado del estado de la piel</td>
    </tr>
</table>
<table border=10 align="right">
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Aromaterapia </center>
    <br><img src="imagenes/aroma.jpg "width="200" height="100" align="left"></td>
    <td>La aromaterapia se basa en el empleo de aceites esenciales de diferentes plantas, <br>
    hierbas y flores, cuyos aromas ayudan a aumentar el bien estar físico,<br>
     mental, emocional y espiritual.</td>
    </tr>
</table>
<table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Acuaterapia </center>
    <br><img src="imagenes/acua.jpg "width="200" height="100" align="left"></td>
    <td>Se trata de una técnica que usa el agua en cualquiera de sus formas para aliviar el malestar,<br>
     así como promover el bienestar físico y mental. Se conoce que este elemento tiene propiedades <br>
     excelentes para nuestra salud. </td>
    </tr>
</table>
<table border=10 align="right">
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Tratamientos <br> de belleza</center>
    <br><img src="imagenes/be.jpg "width="200" height="100" align="left"></td>
    <td>Los tratamientos faciales en el ámbito de la estética y belleza <br>
    son aquellos procedimientos no invasivos que intentan devolver la salud y la belleza <br>
    natural a la delicada piel de nuestro rostro<td>
    </tr>
</table>
<table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> EXFOLIACIÓN <br> CON MIEL</center>
    <br><img src="imagenes/miel.jpg "width="200" height="100" align="left"></td>
    <td> Este tratamiento esta compuesto por miel pura, almendra y suero de leche. Basado en un <br>
    antiguo ritual de belleza, este limpiador natural y exfoliante se aplica con un masaje sobre <br>
    la piel ayudando a purificar y eliminar las células muertas de la piel</td>
    </tr>
</table>




