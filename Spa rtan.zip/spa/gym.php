<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title> SPA RTAP </title>
<link rel="stylesheet" href="css/square.css">
</head>
<body> 
<section class="content">
    <h1 class="title"> - NOVEDADES -<h1> 
    <div class="container">
        <div class="card">
        <figure>
            <img src="imagenes/info.jpg">
</figure>  
            <div class="contenido">
            <h3>INFORMACION</3>
            <P> Pagos,Informacion,Carrito de compras,
                Gestor de calendario, Quejas y Servicios</p>
            <a href="gym1.php"> Ver mas </a>
</div>
</div>

<div class="card">
        <figure>
            <img src="imagenes/mn.jpg">
</figure>
<div class="contenido">
            <h3>GIMNACIO</3>
            <P> Pagos,Informacion,Carrito de compras,
                Gestor de calendario, Quejas y Servicios</p>
            <a href="gym1.php"> Ver mas </a>
</div>
</div>
</section>

</body>
</html>