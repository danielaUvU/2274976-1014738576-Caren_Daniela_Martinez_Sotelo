<tablet>
<img src="imagenes/info.jpg"> 

se necekasdajbnfadjhnfvjnsdjgv
        shfhasbfsbadkfjnsdjkgbnjsdf
        DHAHDFADKSJNFMKSDFNV
        ajdbHADBASBDCNASB
</tablet>


     
        se necekasdajbnfadjhnfvjnsdjgv
        shfhasbfsbadkfjnsdjkgbnjsdf
        DHAHDFADKSJNFMKSDFNV
        ajdbHADBASBDCNASB 