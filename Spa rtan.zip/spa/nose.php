<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title> Menu de navegacion con listas  </title>
<link rel="stylesheet" href="css/estilo.css">
</head>
<body> 
<img src="imagenes/SPA3.jpg "width="120" height="60" align="left">
    <ul class="menu">
        <li> <a href="km.php"> Inicio </a></li>
        <li> <a href="servicio.php"> Atencion al cliente </a></li>
        <li> <a href="acerca.php"> Acerca de  </a></li>
        <li> <a href="contac.php"> Contactos </a></li>
        <p>

        <table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Banco Press</center>
    <br><img src="imagenes/banco.jpg "width="200" height="100" align="left"></td>
    <td>banco plano con soporte para barra sobre la cabeza con el cual se puede realizar<br>
     press de banca para trabajar pectoral, press francés en el cual se trabajan<br>
      los tríceps o cualquier otro ejercicio que necesite de un soporte para que el cuerpo<br>
    permanezca horizontal. Es un equipo básico de cualquier gimnasio. <br>
    Existen bancos que pueden declinarse e inclinarse, también llamados multiangulares,<br>
     y sirven para realizar variantes a los ejercicios dichos o abdominales en diferentes<br>
    posiciones</td>
    </tr>
</table>
<table border=10 align="right">
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Máquina de <br>femorales </center>
    <br><img src="imagenes/maquinas.jpg "width="200" height="100" align="left"></td>
    <td>La máquina en la que el individuo debe trabajar recostado en decúbito ventral, es decir,<br>
     boca abajo, que permite trabajar femorales o isquiotibiales, músculos situados en la parte<br>
      posterior de la pierna. Se pueden realizar en ella ejercicios como curl de piernas <br>
      acostado. También existe máquina de femorales vertical para realizar el curl de piernas <br>
      en posición vertical.</td>
    </tr>
</table>
<table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Prensa de <br> piernas</center>
    <br><img src="imagenes/pierna.jpg "width="200" height="100" align="left"></td>
    <td>sirve para trabajar la parte posterior de las piernas. Es una máquina con respaldar<br>
     inclinado que permite posicionar la espalda y posee una plataforma en la cual debemos<br>
      colocar los pies para levantar con las piernas el peso. Sirve para trabajar sobre todo,<br>
       femorales y glúteos aunque también se puede trabajar en ella cuádriceps y aductores.</td>
    </tr>
</table>
<table border=10 align="right">
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Poleas cruzadas </center>
    <br><img src="imagenes/poleas.jpg "width="200" height="100" align="left"></td>
    <td>esta máquina está conformada por un arco metálico en cuyos dos extremos se <br>
     los pesos y las poleas para tomar de manos y piernas. Es una máquina multifuncion <br>
     ya que en ella se puede trabajar la espalda con cruces de poleas, los brazos en todas <br>
     sus porciones, glúteos y piernas. También existe polea simple y dobles para trabajar <br>
      tren inferior, superior o ambos.</td>
    </tr>
</table>
<table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Dorsales </center>
    <br><img src="imagenes/dorsales.jpg "width="200" height="100" align="left"></td>
    <td>para trabajar la espalda específicamente. Es una máquina con sistema de poleas<br>
     que posee un asiento y soporte para los muslos. Permite trabajar sentados, asiendo una<br>
      barra con las manos con la cual debemos vencer la resistencia del peso al tirar de <br>
      la polea. Trabaja sobre todo, espalda alta mediante jalones tras nuca por ejemplo.</td>
    </tr>
</table>
<table border=10 align="right">
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Paralelas </center>
    <br><img src="imagenes/paralelas.jpg "width="200" height="100" align="left"></td>
    <td> es una máquina muy sencilla que posee una apoyo para antebrazos y para espalda.<br>
     En ella simplemente trabajamos con el peso del cuerpo y se pueden realizar fondos<br>
      para tríceps y pecho o bien, trabajar abdominales al elevar las piernas al pecho.<td>
    </tr>
</table>
<table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Zumba</center>
    <br><img src="imagenes/zumba.jpg "width="200" height="100" align="left"></td>
    <td> es una disciplina deportiva que se imparte en clases dirigidas en la que se realizan<br>
     ejercicios aeróbicos al ritmo de música latina (merengue, samba, reggaeton, cumbia y salsa)<br>
      con la finalidad de perder peso de forma divertida y mejorar el estado de ánimo de los <br>
      deportistas</td>
    </tr>
</table>




