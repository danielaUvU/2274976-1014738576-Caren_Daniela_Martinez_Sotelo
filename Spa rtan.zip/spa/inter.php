
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale-1.0"> 
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tablas</title>
    <link rel="stylesheet" href="css/estilo.css">

<body>

<div class="container">
    <table class="table">
        <caption>Consolas</caption>
        <thead> <align="right">
            <tr>
            <align="right">  <th>Consola</th>
                <th>Precio</th>
            </tr>

        </thead>
        <tbody>
            <tr>
                <td data-label="Consola">Play Station 3</td>
                <td data-label="Precio">$8000</td> 
            </tr>
</thead>
<tbody>
            <tr>
                <td data-label="Consola">Play Station 3</td>
                <td data-label="Precio">$8000</td> 
            </tr>
</thead>


<table width="100%" border="1" cellspacing="0" cellspacing="10">
                <tr>
                    <td bgcolor="blue"><font size="+1" color="red" face="arial">
                    Banco press <br>
                    <img src="imagenes/SPA1.jpg "width="50" height="30" align="left">

                    </td> </font>

                    <td bgcolor="pink"><font size="+1" color="red" face="cursiva"> NIEL DE ESTUDIOS E INTERESES <br>
                        <P>
                            Nivel de estudos <br>
                            
                            <align="right">
                        <input type="radio" name="COLEGIO" value="escolar2"> Certificado escolar <br>
                        <input type="radio" name="COLEGIO" value="escolar2"> Graduado en E.S.O. <br>
                        <input type="radio" name="COLEGIO" value="escolar3"> Bachilller- Formacion Profesional <br>
                        <input type="radio" name="COLEGIO" value="escolar4"> Diplmado <br>
                        <input type="radio" name="COLEGIO" value="escolar5"> Licenciado o Doctorado
                    </td> </font> </P> </align="right">
            </table> 


            <table border=10>
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Banco Press</center>
    <br><img src="imagenes/banco.jpg "width="200" height="100" align="left"></td>
    <td>El banco plano con soporte para barra sobre la cabeza con el cual se puede realizar<br>
     press de banca para trabajar pectoral, press francés en el cual se trabajan<br>
      los tríceps o cualquier otro ejercicio que necesite de un soporte para que el cuerpo<br>
    permanezca horizontal. Es un equipo básico de cualquier gimnasio. <br>
    Existen bancos que pueden declinarse e inclinarse, también llamados multiangulares,<br>
     y sirven para realizar variantes a los ejercicios dichos o abdominales en diferentes<br>
    posiciones</td>
    </tr>
</table>
<table border=10 align="right">
    <tr><td><center> <font size="+1" color="teal" face="Algerian"> Máquina de <br>femorales </center>
    <br><img src="imagenes/maquinas.jpg "width="200" height="100" align="left"></td>
    <td>La máquina en la que el individuo debe trabajar recostado en decúbito ventral, es decir,<br>
     boca abajo, que permite trabajar femorales o isquiotibiales, músculos situados en la parte<br>
      posterior de la pierna. Se pueden realizar en ella ejercicios como curl de piernas <br>
      acostado. También existe máquina de femorales vertical para realizar el curl de piernas <br>
      en posición vertical.</td>
    </tr>
</table>