<html>
    <head><title>Spa Rtam </title></head>
<body>
<img src="imagenes/SPA3.jpg "width="100" height="50" align="left">
<center>
<p align="center">
<a href="inicio.php">Iniciar Seccion </a> <br>
<a href="registro.php">Registarse</a><p>
</center>
<p><br> <p><br>
<tr>
     
     <img src="imagenes/logi.jpg "width="800" height="800" align="left">

<center>
<br> <br> <p> <br> <br> <br> <p> <br> <br> <br> <p> 
<tr><td><font size="5" color="black" align="center" face="Algerian">
 <br>En SPA RTAM te ofrecemos una comodidad para tus tratamientos <br>
para tus zonas capilares, para tus trataientos de cabello, para el ejercico <br>
 y cuidado del cuerpo y elementos de belleza (Polvos,Corrector,iluminador,labial, <br>
mascarillas entre otras) <BR>
</center> <p> </font></td> <br>

           
     