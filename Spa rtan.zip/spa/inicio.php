
<body background="imagenes/azul.jpg"></body>
<link rel="stylesheet" href="css/miestilo.css">
<center> <br> <br> <br> <br> <p> <br> <br> <br> <br> <br> <p> <br> <br> <br> <br> <p> <br> <br> <p> <br> <br> 
<form name=formulario method="post" action="pagina.php">
<table width="80%"  border="2" cellpadding="0" cellspacing="0">
                    <tr>
                        <th colspan=2>Usuario <input type="text" name="usuario" size="50" maxlength="50">
                        Contraseña <input type="password" name="contra" size="50" maxlength="50"></th>
                    </tr>
                    <th colspan=2> <input type="submit" value="Enviar" />
                        </th></tr>
                </form></table> </center>
