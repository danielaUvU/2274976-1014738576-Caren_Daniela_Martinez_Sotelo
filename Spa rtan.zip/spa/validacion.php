<br> <br> <br> <p> <br> <br> <br> <p> <br> <br> <br> <p>
<table width="100%" border="1" cellspacing="0" cellpadding="10">
        <center>
            <td bgcolor="Silver"><font size="1" color="teal" face="Algerian">
             
</center>
<center><h1>  <a href="index.php">Inicio </center> </h1>
<link rel="stylesheet" href="ab.css">
<table width="100%" border="1" cellspacing="10" cellspacing="10">
<center><h1> FORMULARIO DE REGISTRO </center> <tr> </h1>
            <td bgcolor="Silver"><font size="+1" color="black" face="cursiva">  <br>
             <h2> <center>   <font size="+1" color="black" face="comic san ms">
                 
                Nombre de  usuario: <?php $nombre= $_POST['nombre']; echo $nombre; ?> <br>
                Correo Eletronico: <?php $correo= $_POST['correo']; echo $correo; ?> <br>
                Contraseña:<?php $contraseña= $_POST['contra']; echo $contraseña; ?> <br>
                Repetir Contraseña: <?php $direccion= $_POST['contra2']; echo $direccion; ?> <br>
                Nombre: <?php $nombre= $_POST['nombredos']; echo $nombre; ?> <br>
                Apellido <?php $apellido= $_POST['apellido']; echo  $apellido; ?> <br>
             <p>   </td> </font> </h2> </center>
             
 <p>

 <marquee direction=right><img src="imagenes/sPA2.jpg" width="400" height="200">